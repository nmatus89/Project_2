import pymongo
def consult_snap_db():
    json_list = []
    #Connect to mong though PyMongo
    conn = "mongodb://localhost:27017"
    #Create instance of PyMongo
    consult_client = pymongo.MongoClient(conn)
    #Connect to database.
    db = consult_client.snap_db
    #Get collection.
    collection = db.all_states

    for d in collection.find():
        json_list.append(d)

    #json_str = dumps(json_list)
    
    return json_list