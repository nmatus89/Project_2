
  var myMap = L.map("map", {
    // center: [37.8, -96],
    center:[37, -95],
    zoom: 4
  });

  
  var streetmap = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href='https://www.openstreetmap.org/'>OpenStreetMap</a> contributors, <a href='https://creativecommons.org/licenses/by-sa/2.0/'>CC-BY-SA</a>, Imagery © <a href='https://www.mapbox.com/'>Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.streets",
    accessToken: "pk.eyJ1IjoiYXJpdmFyZ2FzYiIsImEiOiJjazByYm16ajIwNG1kM25zN2M4dDRmNGQyIn0.Ya-5ppfCOpgBtfNonUAhCQ"
  }).addTo(myMap);
  

// ###################################
//  II. Heatmap for change in SNAP
// ###################################


//var json_co= "json/SNAP_county_clean.json";
let json_co = data_from_flask

var array_co = [];
//##d3.json(json_co, function(data) {
  //##var changes=data;
  var changes=json_co;
  for (var i = 0; i < changes.length; i++) {
    if (changes[i].semester=="0119" 
    // && changes[i].pop_un_co_per!=""
    && Number(changes[i].snap_biannual_chan)<=0 ){
      var location = changes[i];
    
    array_co.push([location.lat, location.lon,  location.snap_biannual_chan*-1/100 ] );
  };
  };
      // var heat = 
      heatmap = L.heatLayer(array_co, {
        radius: 10,
        min: 0,
        // useLocalExtrema: true,
        max: 1,
        blur: 1,
        minOpacity: 0.2,
        gradient: {
          0.1:  '#f23e45',
          0.3: 'lime',
          0.6: 'yellow',
          0.8: '#FF8300',
          1.0:  'red'
        }
        // gradient: {
        //   0.4:  '#f23e45',
        //   0.50: 'lime',
        //   0.70: 'yellow',
        //   0.95: '#FF8300',
        //   1.0:  'red'
        // }
                     
                      
  }).addTo(myMap);
  console.log(array_co);
  //});



// // ###################################
// //  I. Choropleth for undocumented pop
// // ###################################

  // Create a function to change the color based on enrollment change
  var change = ""
  function getColor(change) {
        return change <= -5  ? '#590a0b' :
        change < -4  ? '#9e1214' :
        change < -3  ? '#E31A1C' :       
        change < -2.5  ? '#FC4E2A' :
        change < -2  ? '#fd5d3c':
        change < -1.5  ? '#FD8D3C' :
        change < -1   ? '#FEB24C' :
        change < 0    ?  '#FED976':	 
        change >= 0   ? '#91ad91' :
         'white';   
    }; 

    function getColorMigr(change) {
      return change >= 5  ? '#84002e' :
      change > 4  ? '#b51516' :
      change > 3  ? '#E31A1C' :       
      change > 2.5  ? '#FC4E2A' :
      change > 2  ? '#FD8D3C':
      change > 1.5  ? '#fdad3c' :
      change > 1   ? '#fec87f' :
      change >= 0   ? '#ffeec2' :
       'white';   
  }; 
  
  // Create an array that holds data for change in state quarterly enrollment
  //##var json = "json/snap_state_quarter.json";
  var json = 'localhost:5000/static/json/snap_state_quarter.json'
  //##var geojson = "json/gz_2010_us_040_00_5m.json";
  var geojson = "localhost:5000/static/json/gz_2010_us_040_00_5m.json";
  console.log(json);
  var array = [];
  d3.json(json, function(data) {
  var changes=data;  
  for (var i = 0; i < changes.length; i++) {
    array.push({
      "state_name": changes[i].state_name,
      "sem0619" : changes[i].snap_chan_t_0619,
      "sem0319" : changes[i].snap_chan_t_0319,
      "sem1218" : changes[i].snap_chan_t_1218,
      "sem0918" : changes[i].snap_chan_t_0918,
      "sem0618" : changes[i].snap_chan_t_0618,
      "sem0318" : changes[i].snap_chan_t_0318,
      "color0619": getColor(changes[i].snap_chan_t_0619),
      "color0319": getColor(changes[i].snap_chan_t_0319),
      "color1218": getColor(changes[i].snap_chan_t_1218),
      "color0918": getColor(changes[i].snap_chan_t_0918),
      "color0618": getColor(changes[i].snap_chan_t_0618),
      "color0318": getColor(changes[i].snap_chan_t_0318),
      "colormig": getColorMigr(changes[i].pop_un_st_per),
      "change": changes[i].snap_biannual_chan,
      "undoc": Number(changes[i].pop_un_st_per).toFixed(1)

    });
  };
  });


  console.log(array);

  d3.json(geojson, function(data1) {
  
    var geodata=data1.features;
// Loop within the array
    for (var i = 0; i < array.length; i++) {
// Loop within each element of the array
      for (var j = 0; j < geodata.length; j++) {
          if 
            (array[i].state_name == geodata[j].properties.NAME) {
            // sem_0119.push(
            // Creating a geoJSON layer with the retrieved data
           L.geoJson(geodata[j], {
              
              // Style each feature (in this case counties)
              style: function(feature) {
                return {
                  color: array[i].colormig,
                  fillColor: array[i].colormig,
                  opacity:0.4,
                  fillOpacity: 0.4,
                  weight: .5
            
                };
              } 
            }).bindPopup("<h3>State: " + array[i].state_name + "</h3> <hr> <h4>Undocumented: " +array[i].undoc  +  "%</h3>")
            .addTo(myMap);
            };
    };
    };

});

// Add title
var populationLegend = L.control({position: 'topright'});
populationLegend.onAdd = function (map) {
var div = L.DomUtil.create('div', 'info legend');
    div.innerHTML +=
    '<h2><strong><center>Undocumented population per state</center></strong></h2>';
return div;
};
populationLegend.addTo(myMap);

// Add legend 
var legend = L.control({position: 'bottomright'});
legend.onAdd = function (map) {
	var div = L.DomUtil.create('div', 'info legend'),
    migpop = [0, 1, 1.5, 2, 2.5, 3, 4, 5],
    labels = [];
    for (var i = 0; i < migpop.length; i++) {
    migpop[i] = migpop[i].toFixed(1); 
    
};
	// loop through our magnitude intervals and generate a label with a colored square for each interval
  div.innerHTML +=  '<strong>Undocumented<br>population (%)</strong><hr><br>' 
  for (var i = 0; i < migpop.length; i++) {
    //alert('<i style="background-color:' + getColor(magnitude[i]) + '"></i> ');
    div.innerHTML += 
    '<i style="background-color:' + getColorMigr(migpop[i]) + ';">&nbsp&nbsp&nbsp;</i> ' +
			migpop[i] + (migpop[i + 1] ? ' - ' + (migpop[i + 1] -.1) + '<br>' : '+');
	}
	return div;
};
legend.addTo(myMap);
