//Prepare container
let tbody = d3.select('tbody');

function dropData(dataset){
    //Remember cleaning table body to get fresh data from filter
    tbody.html('');
    dataset.forEach((dr) => {
        let row=tbody.append('tr');
        Object.values(dr).forEach((value) =>{
            let cell = row.append('td');
            cell.text(value);
        });
    })
}

filterDataArray = [];
function filterData(data){
    data.forEach((d) => {
        filterDataArray.push({
            "state_name": d.state_name,
            "county_name": d.county_name,
            'snap_biannual_chan': d.snap_biannual_chan,
            'semester': d.semester,
            'pop_un_co_per': d.pop_un_co_per,
        });
    });
    return filterDataArray;
};
dropData(filterData(data_from_flask));

function dropDownClick(){
    let selected_state = d3.select('#state').property('value');
    
    let dataFilter = filterDataArray;
    if(selected_state){
        dataFilter = dataFilter.filter((row) => row.state_name === selected_state);
        //console.log(dataFilter);
    }
    dropData(dataFilter)
}
d3.selectAll('#filter-btn').on('click', dropDownClick);